# FRA Prop HQ Tradovate Live Worker v7.7.8

Detection-only copier patch.

## Fix from v7.7.7
Tradovate execution reports can represent a genuine fill with `execType: "Completed"` and `ordStatus: "Filled"`, not only `execType: "Trade"`. v7.7.7 was too strict and could miss TradingView fills.

v7.7.8 treats an execution report as a fill when `lastQty > 0` and any of these are true:
- `execType = Trade`
- `execType = Completed`
- `ordStatus = Filled`

It remains **detection-only**: no follower order placement is enabled. Existing live sync, heartbeat, reconnect and pulse behaviour is preserved.
