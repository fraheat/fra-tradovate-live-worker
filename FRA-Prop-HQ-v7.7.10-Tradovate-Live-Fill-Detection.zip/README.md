# FRA Prop HQ Tradovate Live Worker v7.7.10

Detection-only copier patch.

## Copier detection fix
Tradovate live sync can emit a completed trade as a `fill` entity rather than an `executionReport`. v7.7.9 only inspected `executionReport` frames, so provider events could be arriving normally while the copier never logged the leader fill.

v7.7.10 listens to both:
- `executionReport`
- `fill`

For `fill` events it resolves the associated order when needed to obtain the account, contract and action, then routes the event through the same detection-only copier guardrails.

A five-minute recency guard prevents historical fills from the initial WebSocket snapshot being mistaken for a new leader trade after a worker restart. Dedupe protection remains enabled.

## Safety
Follower order placement is still disabled. This worker only writes `live_leader_fill_detected` events.

## Token session manager
- Worker gets WebSocket credentials from `tradovate-session`.
- Session manager renews Demo tokens against the Demo API, with OAuth refresh-token fallback.
- Worker deliberately reconnects every 55 minutes so tokens are refreshed before expiry.
- No new Render environment variables are required.
