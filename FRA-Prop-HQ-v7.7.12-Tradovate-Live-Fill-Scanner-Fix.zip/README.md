# FRA Prop HQ Tradovate Live Worker v7.7.12

Detection-only copier build.

Fixes a v7.7.11 bug where the initial REST fill-scan timer was scheduled and then immediately cleared without resetting the timer handle. That left the handle truthy, so all later `scheduleCopierFillScan()` calls returned early and the fallback scanner never ran.

Changes:
- Removes the accidental clear of `copierFillScanTimer` after initial subscription.
- Keeps executionReport + fill WebSocket parsing.
- Keeps REST `/fill/list` + `/order/list` fallback scanning on live user events.
- Temporarily uses a 15-minute detection recency window so the latest completed diagnostic trade can be recovered after redeploy without needing another test trade.
- Still detection-only: follower order execution remains disabled.

No new environment variables required.
