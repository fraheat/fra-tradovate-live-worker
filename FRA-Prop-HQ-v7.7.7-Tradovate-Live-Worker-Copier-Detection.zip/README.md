# FRA Prop HQ Tradovate live worker v7.7.7

Persistent Tradovate WebSocket worker for near-real-time account updates and copier leader-fill detection. It opens one `user/syncrequest` subscription per eligible connected login, reconnects automatically, invokes the Supabase `tradovate-live-pulse` Edge Function after provider events, and records matching armed copier leader fills in `copier_events`.

## Required environment variables

- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY`
- `FRA_LIVE_SYNC_WORKER_SECRET`

Optional:

- `TARGET_REFRESH_MS=30000`
- `PULSE_MIN_INTERVAL_MS=2500`
- `HEARTBEAT_MS=15000` — Supabase status heartbeat
- `TRADOVATE_HEARTBEAT_MS=2000` — Tradovate socket heartbeat; keep below 2500 ms

## v7.7.7 — copier detection stage

- Subscribes explicitly to account, order, fill, execution-report and position entity types.
- Detects real `executionReport` Trade events from the selected armed copier leader account.
- Resolves the Tradovate contract name and writes `LIVE LEADER FILL DETECTED` to the FRA Prop HQ copier execution log.
- Uses database dedupe keys so repeated WebSocket updates for the same execution report do not create duplicate copier events.
- This build is **detection only**: it does not place, modify or cancel follower orders.
- Existing live-sync pulse, reconnect and Tradovate heartbeat behaviour is preserved.

## v7.7.6

- Sends the required Tradovate client heartbeat frame `[]` every 2 seconds.
- Responds immediately to server heartbeat frame `h` when needed.
- Keeps the existing Supabase status heartbeat separate from the broker socket heartbeat.
- Logs the actual WebSocket close code and reason instead of only `disconnected`.
- Preserves all v7.7.5 token and `user/syncrequest` fixes.

The worker never places, modifies, or cancels orders. Do not put production secrets in the repository.
