# FRA Prop HQ Tradovate Live Worker v7.7.9

Detection-only copier patch.

## Fix from v7.7.7
Tradovate execution reports can represent a genuine fill with `execType: "Completed"` and `ordStatus: "Filled"`, not only `execType: "Trade"`. v7.7.7 was too strict and could miss TradingView fills.

v7.7.9 treats an execution report as a fill when `lastQty > 0` and any of these are true:
- `execType = Trade`
- `execType = Completed`
- `ordStatus = Filled`

It remains **detection-only**: no follower order placement is enabled. Existing live sync, heartbeat, reconnect and pulse behaviour is preserved.


## v7.7.9 token session manager
- Worker gets WebSocket credentials from the new `tradovate-session` Edge Function.
- The session manager renews Demo tokens against the Demo API, with OAuth refresh-token fallback.
- The worker deliberately reconnects every 55 minutes so tokens are refreshed before the 80-minute expiry.
- No new Render environment variables are required.
