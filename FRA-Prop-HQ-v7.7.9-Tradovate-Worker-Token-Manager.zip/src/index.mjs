import crypto from "node:crypto";
import os from "node:os";
import process from "node:process";
import WebSocket from "ws";
import { createClient } from "@supabase/supabase-js";

const required = ["SUPABASE_URL", "FRA_LIVE_SYNC_WORKER_SECRET"];
for (const name of required) {
  if (!process.env[name]) throw new Error(`${name} is required`);
}
const SERVICE_ROLE_KEY = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SERVICE_ROLE_KEY) throw new Error("SUPABASE_SECRET_KEY or SUPABASE_SERVICE_ROLE_KEY is required");

const SUPABASE_URL = process.env.SUPABASE_URL.replace(/\/$/, "");
const WORKER_SECRET = process.env.FRA_LIVE_SYNC_WORKER_SECRET;
const TARGET_REFRESH_MS = Number(process.env.TARGET_REFRESH_MS || 30000);
const PULSE_MIN_INTERVAL_MS = Number(process.env.PULSE_MIN_INTERVAL_MS || 2500);
const HEARTBEAT_MS = Number(process.env.HEARTBEAT_MS || 15000);
const TRADOVATE_HEARTBEAT_MS = Math.max(1000, Math.min(Number(process.env.TRADOVATE_HEARTBEAT_MS || 2000), 2400));
const INSTANCE_ID = `${os.hostname()}-${process.pid}-${crypto.randomBytes(3).toString("hex")}`;
const SESSION_RECONNECT_MS = Number(process.env.SESSION_RECONNECT_MS || 55 * 60 * 1000);
const VERSION = "7.7.9";

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
  realtime: { transport: WebSocket },
});

const sessions = new Map();
let stopping = false;

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const nowIso = () => new Date().toISOString();
const asText = value => String(value ?? "");

const num = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

function normaliseProviderId(value) {
  return asText(value).trim();
}

function propsEvents(frame) {
  if (asText(frame?.e).toLowerCase() !== "props") return [];
  const details = Array.isArray(frame?.d) ? frame.d : [frame?.d];
  return details.filter(item => item && typeof item === "object");
}

async function tradovateGet(environment, path, token) {
  const response = await fetch(`https://${environment}.tradovateapi.com/v1${path}`, {
    headers: {
      "Accept": "application/json",
      "Authorization": `Bearer ${token}`,
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.errorText) {
    throw new Error(payload?.errorText || payload?.error || `${path} failed (${response.status})`);
  }
  return payload;
}

async function requestWorkerSession(connectionId) {
  const response = await fetch(`${SUPABASE_URL}/functions/v1/tradovate-session`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SERVICE_ROLE_KEY}`,
      "apikey": SERVICE_ROLE_KEY,
      "x-fra-worker-secret": WORKER_SECRET,
    },
    body: JSON.stringify({ connection_id: connectionId }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.error) {
    throw new Error(payload?.error || `Unable to obtain Tradovate live session (${response.status})`);
  }
  const token = asText(payload.access_token).trim();
  const userIds = Array.isArray(payload.user_ids)
    ? payload.user_ids.map(Number).filter(Number.isFinite)
    : [];
  if (!token) throw new Error("Supabase did not return a Tradovate access token");
  if (!userIds.length) throw new Error("Tradovate returned no user IDs for live sync");

  const environment = payload.environment === "live" ? "live" : "demo";
  let accountIds = [];
  try {
    const brokerAccounts = await tradovateGet(environment, "/account/list", token);
    accountIds = [...new Set((Array.isArray(brokerAccounts) ? brokerAccounts : [])
      .map(row => Number(row?.id))
      .filter(Number.isFinite))];
  } catch (error) {
    console.error("unable to preload Tradovate account ids", connectionId, error instanceof Error ? error.message : String(error));
  }
  if (!accountIds.length) {
    const { data: links, error: linksError } = await supabase
      .from("provider_account_links")
      .select("provider_account_id")
      .eq("connection_id", connectionId)
      .not("provider_account_id", "is", null);
    if (linksError) throw linksError;
    accountIds = [...new Set((links || [])
      .map(row => Number(row.provider_account_id))
      .filter(Number.isFinite))];
  }

  return {
    token,
    userIds,
    accountIds,
    environment,
    wsUrl: asText(payload.websocket_url).trim(),
  };
}

function isPaidTarget(ownerId, profileById, subscriptionByOwner) {
  const profile = profileById.get(ownerId) || {};
  const subscription = subscriptionByOwner.get(ownerId) || {};
  const role = asText(profile.role).toLowerCase();
  const plan = asText(profile.plan || subscription.plan).toLowerCase();
  const status = asText(subscription.status).toLowerCase();
  if (role === "admin" || ["founder", "business", "desk"].includes(plan)) return true;
  return ["entry", "plus", "pro"].includes(plan) && ["active", "trialing", "past_due"].includes(status);
}

async function loadTargets() {
  const { data: connections, error } = await supabase.from("provider_connections")
    .select("id,owner_id,provider,environment,status,display_name,metadata,live_sync_enabled")
    .eq("provider", "tradovate")
    .in("status", ["connected", "syncing"])
    .eq("live_sync_enabled", true);
  if (error) throw error;
  const ownerIds = [...new Set((connections || []).map(row => row.owner_id).filter(Boolean))];
  if (!ownerIds.length) return [];
  const [{ data: profiles, error: profileError }, { data: subscriptions, error: subscriptionError }] = await Promise.all([
    supabase.from("profiles").select("id,role,plan").in("id", ownerIds),
    supabase.from("subscriptions").select("owner_id,plan,status,current_period_end").in("owner_id", ownerIds),
  ]);
  if (profileError) throw profileError;
  if (subscriptionError) throw subscriptionError;
  const profileById = new Map((profiles || []).map(row => [row.id, row]));
  const subscriptionByOwner = new Map((subscriptions || []).map(row => [row.owner_id, row]));
  return (connections || []).filter(row => isPaidTarget(row.owner_id, profileById, subscriptionByOwner));
}

async function writeStatus(connection, patch) {
  const environment = asText(connection?.metadata?.technical_environment || connection.environment) === "live" ? "live" : "demo";
  const { error } = await supabase.from("tradovate_live_status").upsert({
    connection_id: connection.id,
    owner_id: connection.owner_id,
    provider_environment: environment,
    worker_instance: INSTANCE_ID,
    transport: "websocket",
    ...patch,
    updated_at: nowIso(),
  }, { onConflict: "connection_id" });
  if (error) console.error("status update failed", connection.id, error.message);
  await supabase.from("provider_connections").update({
    live_sync_state: patch.state || "live",
    live_sync_last_event_at: patch.last_event_at,
    live_sync_last_heartbeat_at: patch.last_heartbeat_at || nowIso(),
  }).eq("id", connection.id);
}

function sendRequest(ws, endpoint, id, body) {
  const payload = body === undefined || body === null
    ? `${endpoint}\n${id}\n\n`
    : `${endpoint}\n${id}\n\n${typeof body === "string" ? body : JSON.stringify(body)}`;
  ws.send(payload);
}

function frameError(frame, fallback) {
  const detail = frame?.d;
  if (typeof detail === "string" && detail.trim()) return detail.trim();
  if (detail && typeof detail === "object") {
    return asText(detail.errorText || detail.error || detail.message || fallback);
  }
  return fallback;
}

function unpackFrame(rawValue) {
  const raw = asText(rawValue);
  if (!raw || raw === "o" || raw === "h") return [];
  if (!raw.startsWith("a")) return [];
  let outer;
  try { outer = JSON.parse(raw.slice(1)); } catch { return []; }
  const items = [];
  for (const value of Array.isArray(outer) ? outer : [outer]) {
    if (typeof value === "string") {
      try { items.push(JSON.parse(value)); } catch { items.push({ raw: value }); }
    } else if (value && typeof value === "object") items.push(value);
  }
  return items;
}

class LiveSession {
  constructor(connection) {
    this.connection = connection;
    this.ws = null;
    this.stopped = false;
    this.authorized = false;
    this.subscribed = false;
    this.reconnectCount = 0;
    this.eventCount = 0;
    this.pulseCount = 0;
    this.lastPulseAt = 0;
    this.pulseTimer = null;
    this.pulseInFlight = false;
    this.pulseQueued = false;
    this.heartbeatTimer = null;
    this.socketHeartbeatTimer = null;
    this.sessionRefreshTimer = null;
    this.lastClientHeartbeatAt = 0;
    this.lastCloseInfo = "";
    this.backoffMs = 1000;
    this.accessToken = "";
    this.environment = "demo";
    this.contractNameCache = new Map();
    this.copierEventInFlight = new Set();
  }

  updateConnection(connection) { this.connection = connection; }

  async start() {
    while (!this.stopped && !stopping) {
      try {
        await this.connectOnce();
      } catch (error) {
        if (this.stopped || stopping) break;
        const message = error instanceof Error ? error.message : String(error);
        console.error("live connection failed", {
          connection_id: this.connection.id,
          display_name: this.connection.display_name || "Tradovate login",
          environment: this.connection.environment || "demo",
          error: message,
        });
        this.reconnectCount += 1;
        await writeStatus(this.connection, {
          state: "reconnecting",
          reconnect_count: this.reconnectCount,
          last_error: message,
          last_heartbeat_at: nowIso(),
        });
        await sleep(this.backoffMs + Math.floor(Math.random() * 500));
        this.backoffMs = Math.min(this.backoffMs * 2, 30000);
      }
    }
  }

  async loadCredential() {
    return requestWorkerSession(this.connection.id);
  }

  async resolveContractName(contractId) {
    const key = normaliseProviderId(contractId);
    if (!key) return "";
    if (this.contractNameCache.has(key)) return this.contractNameCache.get(key);
    try {
      const contract = await tradovateGet(this.environment, `/contract/item?id=${encodeURIComponent(key)}`, this.accessToken);
      const name = asText(contract?.name).trim();
      if (name) this.contractNameCache.set(key, name);
      return name;
    } catch (error) {
      console.error("contract lookup failed", this.connection.id, key, error instanceof Error ? error.message : String(error));
      return "";
    }
  }

  async detectLeaderExecution(report, eventType) {
    const reportId = normaliseProviderId(report?.id);
    const providerAccountId = normaliseProviderId(report?.accountId);
    const contractId = normaliseProviderId(report?.contractId);
    const execType = asText(report?.execType).trim().toLowerCase();
    const ordStatus = asText(report?.ordStatus).trim().toLowerCase();
    const action = asText(report?.action).trim();
    const quantity = Math.abs(num(report?.lastQty));
    // Tradovate can report a fill as execType=Trade OR execType=Completed
    // (often with ordStatus=Filled). lastQty > 0 is the key evidence that an
    // actual execution happened. v7.7.7 only accepted execType=Trade and
    // therefore missed normal completed fills from TradingView/Tradovate.
    const isFillReport = quantity >= 1 && (
      execType === "trade" ||
      execType === "completed" ||
      ordStatus === "filled"
    );
    if (!reportId || !providerAccountId || !isFillReport) return;

    const inFlightKey = `${this.connection.id}:${reportId}`;
    if (this.copierEventInFlight.has(inFlightKey)) return;
    this.copierEventInFlight.add(inFlightKey);

    try {
      const { data: link, error: linkError } = await supabase
        .from("provider_account_links")
        .select("account_id,provider_account_id")
        .eq("connection_id", this.connection.id)
        .eq("provider_account_id", providerAccountId)
        .maybeSingle();
      if (linkError) throw linkError;

      let localAccountId = link?.account_id || null;
      if (!localAccountId) {
        const { data: fallbackAccount, error: fallbackError } = await supabase
          .from("accounts")
          .select("id")
          .eq("owner_id", this.connection.owner_id)
          .eq("external_id", providerAccountId)
          .eq("is_archived", false)
          .maybeSingle();
        if (fallbackError) throw fallbackError;
        localAccountId = fallbackAccount?.id || null;
      }
      if (!localAccountId) return;

      const { data: groups, error: groupError } = await supabase
        .from("copier_groups")
        .select("id,owner_id,name,mode,armed,leader_account_id,max_leader_qty,allowed_symbols")
        .eq("owner_id", this.connection.owner_id)
        .eq("leader_account_id", localAccountId)
        .eq("armed", true);
      if (groupError) throw groupError;
      if (!groups?.length) return;

      const symbol = await this.resolveContractName(contractId);
      const providerFillId = normaliseProviderId(report?.execRefId || report?.id);
      const providerOrderId = normaliseProviderId(report?.orderId);
      const timestamp = asText(report?.timestamp).trim() || nowIso();

      for (const group of groups) {
        const allowedSymbols = Array.isArray(group.allowed_symbols)
          ? group.allowed_symbols.map(value => asText(value).trim().toUpperCase()).filter(Boolean)
          : [];
        const normalizedSymbol = symbol.toUpperCase();
        const symbolBlocked = allowedSymbols.length && normalizedSymbol && !allowedSymbols.includes(normalizedSymbol);
        const quantityBlocked = quantity > Math.max(1, num(group.max_leader_qty, 1));
        const status = symbolBlocked || quantityBlocked ? "blocked" : "success";
        const reason = symbolBlocked
          ? `${symbol || `Contract ${contractId}`} is not allowed by this copier group`
          : quantityBlocked
            ? `Leader fill quantity ${quantity} exceeds copier max ${Math.max(1, num(group.max_leader_qty, 1))}`
            : null;
        const message = reason
          ? `LIVE LEADER FILL BLOCKED · ${reason}`
          : `LIVE LEADER FILL DETECTED · ${action || "Trade"} ${quantity} ${symbol || `Contract ${contractId}`}`;
        const dedupeKey = `live:${this.connection.id}:executionReport:${reportId}:group:${group.id}`;
        const { error: insertError } = await supabase.from("copier_events").insert({
          owner_id: this.connection.owner_id,
          group_id: group.id,
          leader_account_id: localAccountId,
          event_type: "live_leader_fill_detected",
          status,
          dedupe_key: dedupeKey,
          provider_order_id: providerOrderId || null,
          provider_fill_id: providerFillId || reportId,
          symbol: symbol || null,
          action: action || null,
          quantity,
          message,
          payload: {
            stage: "detection_only",
            execution_enabled: false,
            connection_id: this.connection.id,
            provider_account_id: providerAccountId,
            contract_id: contractId || null,
            execution_report_id: reportId,
            event_type: eventType || null,
            provider_timestamp: timestamp,
            last_price: num(report?.lastPx, null),
            avg_price: num(report?.avgPx, null),
            raw_execution_report: report,
          },
          created_at: timestamp,
        });
        if (insertError && insertError.code !== "23505") throw insertError;
        if (!insertError) {
          console.log("copier leader fill detected", {
            connection_id: this.connection.id,
            group_id: group.id,
            leader_account_id: localAccountId,
            provider_account_id: providerAccountId,
            action,
            quantity,
            symbol: symbol || null,
            report_id: reportId,
          });
        }
      }
    } catch (error) {
      console.error("copier leader detection failed", this.connection.id, error instanceof Error ? error.message : String(error));
    } finally {
      setTimeout(() => this.copierEventInFlight.delete(inFlightKey), 30000).unref?.();
    }
  }

  handleCopierFrame(frame) {
    for (const detail of propsEvents(frame)) {
      const entityType = asText(detail?.entityType).trim().toLowerCase();
      const eventType = asText(detail?.eventType).trim();
      if (entityType !== "executionreport") continue;
      const entities = Array.isArray(detail?.entity) ? detail.entity : [detail?.entity];
      for (const entity of entities) {
        if (!entity || typeof entity !== "object") continue;
        this.detectLeaderExecution(entity, eventType).catch(error =>
          console.error("copier frame handler failed", this.connection.id, error instanceof Error ? error.message : String(error))
        );
      }
    }
  }

  async connectOnce() {
    this.authorized = false;
    this.subscribed = false;
    this.lastCloseInfo = "";
    const { token, userIds, accountIds, environment, wsUrl: brokeredWsUrl } = await this.loadCredential();
    this.accessToken = token;
    this.environment = environment;
    const wsUrl = brokeredWsUrl || `wss://${environment}.tradovateapi.com/v1/websocket`;

    await writeStatus(this.connection, {
      state: "connecting",
      last_error: null,
      reconnect_count: this.reconnectCount,
      last_heartbeat_at: nowIso(),
    });

    await new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl, { handshakeTimeout: 20000 });
      this.ws = ws;
      let settled = false;

      const finishReject = error => {
        if (!settled) {
          settled = true;
          try { ws.close(1011, "connection-failed"); } catch {}
          reject(error);
        }
      };

      const sendSocketHeartbeat = () => {
        if (ws.readyState !== WebSocket.OPEN) return;
        try {
          ws.send("[]");
          this.lastClientHeartbeatAt = Date.now();
        } catch (error) {
          console.error("Tradovate heartbeat send failed", this.connection.id, error instanceof Error ? error.message : String(error));
        }
      };

      ws.on("open", () => {
        sendRequest(ws, "authorize", 0, token);
        this.socketHeartbeatTimer = setInterval(sendSocketHeartbeat, TRADOVATE_HEARTBEAT_MS);
      });
      ws.on("message", async raw => {
        const rawText = asText(raw);
        if (rawText === "h") {
          if (Date.now() - this.lastClientHeartbeatAt >= 1000) sendSocketHeartbeat();
          return;
        }
        const frames = unpackFrame(rawText);
        if (!frames.length) return;
        for (const frame of frames) {
          if (Number(frame.i) === 0) {
            if (Number(frame.s) !== 200) {
              return finishReject(new Error(`websocket authorize: ${frameError(frame, "Tradovate WebSocket authorization failed")}`));
            }
            this.authorized = true;
            const syncBody = accountIds?.length
              ? {
                  accounts: accountIds,
                  splitResponses: true,
                  entityTypes: [
                    "account",
                    "accountRiskStatus",
                    "cashBalance",
                    "commandReport",
                    "command",
                    "executionReport",
                    "fill",
                    "fillPair",
                    "order",
                    "orderStrategy",
                    "position",
                  ],
                }
              : { users: userIds, splitResponses: true };
            sendRequest(ws, "user/syncrequest", 1, syncBody);
            continue;
          }
          if (Number(frame.i) === 1 && Number(frame.s) >= 400) {
            return finishReject(new Error(`user/syncrequest: ${frameError(frame, "Tradovate user synchronization failed")}`));
          }
          if (Number(frame.i) === 1 && Number(frame.s) === 200 && !this.subscribed) {
            this.subscribed = true;
            this.backoffMs = 1000;
            await writeStatus(this.connection, {
              state: "live",
              last_connected_at: nowIso(),
              last_heartbeat_at: nowIso(),
              reconnect_count: this.reconnectCount,
              event_count: this.eventCount,
              pulse_count: this.pulseCount,
              last_error: null,
            });
            this.schedulePulse("initial-live-snapshot", 350);
            if (this.sessionRefreshTimer) clearTimeout(this.sessionRefreshTimer);
            this.sessionRefreshTimer = setTimeout(() => {
              if (this.ws?.readyState === WebSocket.OPEN) {
                console.log("scheduled Tradovate token refresh reconnect", this.connection.id);
                try { this.ws.close(1000, "scheduled-token-refresh"); } catch {}
              }
            }, SESSION_RECONNECT_MS);
            this.sessionRefreshTimer.unref?.();
            if (!settled) { settled = true; resolve(); }
            continue;
          }

          if (this.authorized) {
            this.handleCopierFrame(frame);
            this.eventCount += 1;
            const eventAt = nowIso();
            await writeStatus(this.connection, {
              state: "live",
              last_event_at: eventAt,
              last_heartbeat_at: eventAt,
              event_count: this.eventCount,
              reconnect_count: this.reconnectCount,
              last_error: null,
            });
            this.schedulePulse("tradovate-user-event");
          }
        }
      });
      ws.on("error", finishReject);
      ws.on("close", (code, reason) => {
        this.lastCloseInfo = `Tradovate WebSocket closed (${code}) ${asText(reason)}`.trim();
        this.clearHeartbeat();
        this.authorized = false;
        this.subscribed = false;
        this.ws = null;
        if (!this.stopped && !stopping) finishReject(new Error(`Tradovate WebSocket closed (${code}) ${asText(reason)}`.trim()));
        else if (!settled) { settled = true; resolve(); }
      });

      this.heartbeatTimer = setInterval(() => {
        writeStatus(this.connection, {
          state: this.subscribed ? "live" : "connecting",
          last_heartbeat_at: nowIso(),
          event_count: this.eventCount,
          pulse_count: this.pulseCount,
          reconnect_count: this.reconnectCount,
        }).catch(error => console.error("heartbeat failed", error));
      }, HEARTBEAT_MS);
    });

    while (!this.stopped && !stopping && this.ws?.readyState === WebSocket.OPEN) await sleep(1000);
    if (!this.stopped && !stopping) throw new Error(this.lastCloseInfo || "Tradovate WebSocket disconnected");
  }

  clearHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.socketHeartbeatTimer) clearInterval(this.socketHeartbeatTimer);
    if (this.sessionRefreshTimer) clearTimeout(this.sessionRefreshTimer);
    this.heartbeatTimer = null;
    this.socketHeartbeatTimer = null;
    this.sessionRefreshTimer = null;
  }

  schedulePulse(reason, delay = PULSE_MIN_INTERVAL_MS) {
    if (this.stopped || stopping) return;
    if (this.pulseTimer) clearTimeout(this.pulseTimer);
    const sinceLast = Date.now() - this.lastPulseAt;
    const wait = Math.max(delay, PULSE_MIN_INTERVAL_MS - sinceLast, 0);
    this.pulseTimer = setTimeout(() => this.runPulse(reason), wait);
  }

  async runPulse(reason) {
    this.pulseTimer = null;
    if (this.pulseInFlight) {
      this.pulseQueued = true;
      return;
    }
    this.pulseInFlight = true;
    this.lastPulseAt = Date.now();
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/tradovate-live-pulse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${SERVICE_ROLE_KEY}`,
          "apikey": SERVICE_ROLE_KEY,
          "x-fra-worker-secret": WORKER_SECRET,
        },
        body: JSON.stringify({ connection_id: this.connection.id, reason }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || payload?.error) throw new Error(payload?.error || `Live pulse failed (${response.status})`);
      this.pulseCount += 1;
      await writeStatus(this.connection, {
        state: payload.requires_full_sync ? "attention" : "live",
        last_pulse_at: nowIso(),
        last_success_at: nowIso(),
        last_heartbeat_at: nowIso(),
        pulse_count: this.pulseCount,
        event_count: this.eventCount,
        last_error: payload.requires_full_sync ? "A newly detected account needs one full sync" : null,
        metadata: { last_pulse_result: payload, last_reason: reason },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error("live pulse failed", this.connection.id, message);
      await writeStatus(this.connection, {
        state: "attention",
        last_heartbeat_at: nowIso(),
        last_error: message,
        pulse_count: this.pulseCount,
        event_count: this.eventCount,
      });
    } finally {
      this.pulseInFlight = false;
      if (this.pulseQueued) {
        this.pulseQueued = false;
        this.schedulePulse("queued-provider-event", 350);
      }
    }
  }

  async stop(reason = "stopped") {
    this.stopped = true;
    if (this.pulseTimer) clearTimeout(this.pulseTimer);
    this.clearHeartbeat();
    try { this.ws?.close(1000, reason); } catch {}
    this.ws = null;
    await writeStatus(this.connection, {
      state: reason === "not-eligible" ? "manual" : "offline",
      last_heartbeat_at: nowIso(),
      last_error: reason === "not-eligible" ? "Live sync is available on paid plans" : null,
    });
  }
}

async function reconcileTargets() {
  const targets = await loadTargets();
  const targetById = new Map(targets.map(row => [row.id, row]));

  for (const [id, session] of sessions) {
    const target = targetById.get(id);
    if (!target) {
      sessions.delete(id);
      await session.stop("not-eligible");
    } else {
      session.updateConnection(target);
    }
  }

  for (const target of targets) {
    if (sessions.has(target.id)) continue;
    const session = new LiveSession(target);
    sessions.set(target.id, session);
    session.start().catch(error => console.error("session stopped unexpectedly", target.id, error));
  }

  const liveCount = [...sessions.values()].filter(session => session.subscribed && session.ws?.readyState === WebSocket.OPEN).length;
  const connectingCount = Math.max(sessions.size - liveCount, 0);
  console.log(`[${nowIso()}] live targets=${targets.length} subscribed=${liveCount} connecting=${connectingCount}`);
}

async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`received ${signal}; closing ${sessions.size} live sessions`);
  await Promise.allSettled([...sessions.values()].map(session => session.stop("worker-shutdown")));
  process.exit(0);
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", error => console.error("unhandled rejection", error));
process.on("uncaughtException", error => console.error("uncaught exception", error));

console.log(`FRA Prop HQ Tradovate live worker v${VERSION} starting as ${INSTANCE_ID}`);
await reconcileTargets();
while (!stopping) {
  await sleep(TARGET_REFRESH_MS);
  try { await reconcileTargets(); } catch (error) { console.error("target refresh failed", error); }
}
