# FRA Prop HQ Tradovate Live Worker v7.7.16

Stage-2 single-follower execution build.

## What changed from v7.7.15
- Keeps real-fill-first dedupe with delayed position fallback.
- Adds live follower routing only when the copier group is `mode=live`, armed, and the follower is enabled.
- Uses Tradovate `POST /order/placeorder` market orders with `isAutomated: true`.
- Uses deterministic `clOrdId` plus database reservation dedupe before any provider order is submitted.
- Resolves each Tradovate login's `accountSpec` from the authenticated user.
- Supports follower accounts on another connected Tradovate session by routing through that connection's worker session.
- Enforces follower max quantity, allowed symbols, active-account status, and configured daily-loss stop before submission.
- Logs reserved, submitted, rejected, and blocked follower events in `copier_events`.
- Writes worker checkpoint version `7.7.16` to `provider_sync_checkpoints`.

## Safety state at delivery
The database copier group should remain in `simulation` mode while deploying this build. No follower order is submitted until the group is explicitly switched to `live`.

Initial Stage-2 rollout is intended for follower APEX49364100000132 only, max quantity 1, MNQ only. Other followers should remain disabled until the first live entry and exit are verified.
